﻿namespace Lancamentos.Domain.Enums;

public enum TipoLancamento
{
    Credito = 1,
    Debito = 2
}
