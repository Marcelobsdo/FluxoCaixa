﻿namespace Consolidado.Domain.Exceptions;

public class DomainException(string message) : Exception(message)
{
}
