﻿using Consolidado.Application.DTOs;
using Consolidado.Application.Interfaces;
using Dapper;
using Npgsql;

namespace Consolidado.Infrastructure.Queries;

public sealed class ConsolidadoReadService : IConsolidadoReadService
{
    private readonly string _cs;

    public ConsolidadoReadService(string cs) => _cs = cs;

    public async Task<SaldoDiarioDto?> ObterSaldoDiarioAsync(Guid comercianteId, DateTime dia, CancellationToken ct)
    {
        const string sql = @"SELECT
                              comerciante_id AS ""ComercianteId"",
                              dia::date      AS ""Dia"",
                              COALESCE(SUM(CASE WHEN tipo = 1 THEN valor ELSE 0 END), 0) AS ""TotalCreditos"",
                              COALESCE(SUM(CASE WHEN tipo = 2 THEN valor ELSE 0 END), 0) AS ""TotalDebitos"",
                              COALESCE(SUM(CASE WHEN tipo = 1 THEN valor ELSE -valor END), 0) AS ""Saldo""
                            FROM lancamentos
                            WHERE comerciante_id = @ComercianteId
                              AND dia = @Dia::date
                            GROUP BY comerciante_id, dia::date;";

        await using var conn = new NpgsqlConnection(_cs);

        return await conn.QuerySingleOrDefaultAsync<SaldoDiarioDto>(
            new CommandDefinition(sql, new { ComercianteId = comercianteId, Dia = dia }, cancellationToken: ct));
    }
}
