﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Consolidado.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddProcessedEvent : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "processed_event",
                columns: table => new
                {
                    event_id = table.Column<Guid>(type: "uuid", nullable: false),
                    event_name = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    processed_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_processed_event", x => x.event_id);
                });

            migrationBuilder.CreateTable(
                name: "saldo_diario",
                columns: table => new
                {
                    comerciante_id = table.Column<Guid>(type: "uuid", nullable: false),
                    dia = table.Column<DateTime>(type: "date", nullable: false),
                    total_creditos = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    total_debitos = table.Column<decimal>(type: "numeric(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_saldo_diario", x => new { x.comerciante_id, x.dia });
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "processed_event");

            migrationBuilder.DropTable(
                name: "saldo_diario");
        }
    }
}
